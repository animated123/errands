
export enum UserRole {
  REQUESTER = 'requester',
  RUNNER = 'runner'
}

export enum ErrandStatus {
  PENDING = 'pending',
  ACCEPTED = 'accepted',
  VERIFYING = 'verifying', // Runner has submitted for review
  COMPLETED = 'completed', // Requester has signed off
  CANCELLED = 'cancelled'
}

export enum NotificationType {
  NEW_BID = 'new_bid',
  BID_ACCEPTED = 'bid_accepted',
  JOB_SUBMITTED = 'job_submitted',
  JOB_COMPLETED = 'job_completed',
  NEW_MESSAGE = 'new_message'
}

export interface AppNotification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  errandId: string;
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Bid {
  runnerId: string;
  runnerName: string;
  price: number;
  timestamp: number;
  runnerRating: number;
  eta?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

export interface Transaction {
  id: string;
  amount: number;
  type: 'earning' | 'withdrawal';
  description: string;
  timestamp: number;
  errandId?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  createdAt: number;
  isVerified: boolean;
  phone?: string;
  address?: string;
  rating: number;
  ratingCount: number;
  isOnline?: boolean;
  lastKnownLocation?: Coordinates;
  // Financial fields for runners
  balanceOnHold?: number;
  balanceWithdrawn?: number;
  transactions?: Transaction[];
}

export interface Errand {
  id: string;
  title: string;
  description: string;
  pickupLocation: string;
  pickupCoordinates: Coordinates;
  dropoffLocation: string;
  dropoffCoordinates: Coordinates;
  budget: number;
  deadline: string; // ISO Date string
  requesterId: string;
  requesterName: string;
  requesterRating: number;
  runnerId: string | null;
  status: ErrandStatus;
  createdAt: number;
  jobStartedAt?: number;
  completedAt?: number;
  runnerComments?: string;
  signature?: string;
  bids: Bid[];
  chat: ChatMessage[];
  acceptedPrice?: number;
  requesterRated?: boolean;
  runnerRated?: boolean;
  eta?: string;
  distanceKm?: number;
  runnerRatingGiven?: number;
  currentRunnerStatus?: string; // New: Picked package, heading to target, etc.
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
}
