
import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  color?: string;
}

const Logo: React.FC<LogoProps> = ({ className, size = 100, color = "currentColor" }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Ground Shadow */}
      <ellipse cx="50" cy="82" rx="18" ry="1.5" fill={color} fillOpacity="0.1" />
      
      {/* Walking Shopper Silhouette */}
      <g fill={color}>
        {/* Head */}
        <circle cx="53" cy="18" r="4.5" />
        
        {/* Body/Suit */}
        <path d="M51 24c-2.5 0-4.5 2-4.5 4.5v3l-2.5 15.5h10.5l-1-18.5c0-2.5-1.5-4.5-2.5-4.5z" />
        
        {/* Back Arm (Left) carrying bags */}
        <path d="M46.5 28.5L42 38.5h2l.5 2.5h-4.5l1.5-4.5h2.5L46.5 28.5z" />
        <rect x="34" y="41" width="8" height="11" rx="0.5" transform="rotate(10 34 41)" />
        <rect x="37" y="42" width="8" height="11" rx="0.5" transform="rotate(10 37 42)" fillOpacity="0.7" />
        
        {/* Front Arm (Right) carrying bags */}
        <path d="M55.5 28.5L59 38.5h-2l-.5 2.5h4.5l-1.5-4.5H57l-1.5-8z" />
        <rect x="58" y="41" width="8" height="11" rx="0.5" transform="rotate(-10 58 41)" />
        <rect x="61" y="42" width="8" height="11" rx="0.5" transform="rotate(-10 61 42)" fillOpacity="0.7" />

        {/* Legs - Walking Pose */}
        <path d="M49 47l-6.5 21.5-4.5 2 2 2.5 8.5-24-0.5-2z" /> {/* Forward Leg */}
        <path d="M52.5 47l3.5 16 4 11 6 2.5-3.5-4.5-4.5-12.5-2-12.5z" /> {/* Back Leg */}
        
        {/* Feet Details */}
        <path d="M37.5 70.5l2 3h4l-1-3h-5z" />
        <path d="M62 76.5l3 3.5h5l-2-3.5h-6z" />
      </g>
    </svg>
  );
};

export default Logo;
