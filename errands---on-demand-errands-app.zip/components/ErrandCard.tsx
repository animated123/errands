
import React from 'react';
import { Errand, ErrandStatus } from '../types';
import { MapPin, DollarSign, Clock, ChevronRight, ArrowRight, Globe, Bike } from 'lucide-react';

interface ErrandCardProps {
  errand: Errand;
  onClick: (errand: Errand) => void;
}

const ErrandCard: React.FC<ErrandCardProps> = ({ errand, onClick }) => {
  const getStatusColor = (status: ErrandStatus) => {
    switch (status) {
      case ErrandStatus.PENDING: return 'bg-amber-100 text-amber-700';
      case ErrandStatus.ACCEPTED: return 'bg-blue-100 text-blue-700';
      case ErrandStatus.VERIFYING: return 'bg-indigo-100 text-indigo-700';
      case ErrandStatus.COMPLETED: return 'bg-emerald-100 text-emerald-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div 
      onClick={() => onClick(errand)}
      className="bg-white rounded-xl border border-gray-100 p-3.5 shadow-sm active:scale-[0.98] transition-all cursor-pointer"
    >
      <div className="flex justify-between items-start mb-2.5">
        <h3 className="font-bold text-gray-900 line-clamp-1 flex-1 mr-2 text-sm">{errand.title}</h3>
        <span className={`text-[8px] uppercase font-black px-2 py-0.5 rounded-md shrink-0 ${getStatusColor(errand.status)}`}>
          {errand.status}
        </span>
      </div>
      
      <div className="flex items-center gap-2 mb-3">
         <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-medium mb-1">
               <div className="w-1 h-1 rounded-full bg-emerald-500"></div>
               <span className="truncate">{errand.pickupLocation}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-medium">
               <div className="w-1 h-1 rounded-full bg-red-500"></div>
               <span className="truncate">{errand.dropoffLocation}</span>
            </div>
         </div>
         <div className="text-right shrink-0">
           <div className="flex items-center gap-1 text-[9px] font-black text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-md mb-1">
             <Globe size={8} />
             {errand.distanceKm} KM
           </div>
         </div>
      </div>

      {errand.currentRunnerStatus && errand.status !== ErrandStatus.PENDING && (
        <div className="mb-3 px-2 py-1.5 bg-gray-50 rounded-lg flex items-center gap-2">
           <Bike size={12} className="text-indigo-400" />
           <span className="text-[9px] font-bold text-gray-500 line-clamp-1">{errand.currentRunnerStatus}</span>
        </div>
      )}

      <div className="flex items-center justify-between pt-2.5 border-t border-gray-50">
        <div className="text-emerald-600 font-black text-xs">
           Ksh {errand.acceptedPrice || errand.budget}
        </div>
        <div className="flex items-center text-indigo-600 font-bold text-[9px] uppercase tracking-widest">
          Details <ChevronRight size={12} />
        </div>
      </div>
    </div>
  );
};

export default ErrandCard;
