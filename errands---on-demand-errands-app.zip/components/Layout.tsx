
import React, { useState, useEffect } from 'react';
import { User, UserRole, AppNotification, NotificationType } from '../types';
import { LayoutDashboard, PlusCircle, UserCircle, LogOut, Briefcase, Bell, Clock, X, ChevronRight, Check, Search } from 'lucide-react';
import { firebaseService } from '../services/mockFirebase';
import Logo from './Logo';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onNotificationClick?: (notification: AppNotification) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, activeTab, setActiveTab, onNotificationClick }) => {
  const [showNotifs, setShowNotifs] = useState(false);
  const [notifs, setNotifs] = useState<AppNotification[]>([]);

  useEffect(() => {
    if (user) {
      const fetch = async () => {
        const list = await firebaseService.fetchNotifications(user.id);
        setNotifs(list);
      };
      fetch();
      const interval = setInterval(fetch, 10000); // Poll for notifications
      return () => clearInterval(interval);
    }
  }, [user]);

  if (!user) return <>{children}</>;

  const isRequester = user.role === UserRole.REQUESTER;
  const unreadCount = notifs.filter(n => !n.read).length;

  const handleOpenNotifs = async () => {
    setShowNotifs(true);
    await firebaseService.markNotificationsAsRead(user.id);
    const updated = await firebaseService.fetchNotifications(user.id);
    setNotifs(updated);
  };

  const navItems = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    ...(isRequester 
      ? [{ id: 'create', label: 'Post', icon: PlusCircle }] 
      : [{ id: 'find', label: 'Explore', icon: Search }]
    ),
    { id: 'active', label: 'Profile', icon: UserCircle },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 max-w-md mx-auto relative shadow-xl overflow-x-hidden">
      {/* Header */}
      <header className="bg-white px-6 py-4 flex items-center justify-between border-b sticky top-0 z-40 backdrop-blur-md bg-white/90">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gray-900 rounded-xl flex items-center justify-center shadow-md">
            <Logo size={28} color="white" />
          </div>
          <h1 className="text-xl font-black text-gray-900 tracking-tight">Errands</h1>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleOpenNotifs}
            className="p-3 bg-gray-50 text-gray-400 rounded-2xl relative hover:text-indigo-600 transition-colors"
          >
            <Bell size={20} />
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 w-4 h-4 bg-red-500 text-white text-[8px] font-black flex items-center justify-center rounded-full border-2 border-white">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Notification Sidebar Overlay */}
      {showNotifs && (
        <div className="fixed inset-0 z-[100] bg-gray-900/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="absolute right-0 top-0 bottom-0 w-[85%] max-w-xs bg-white shadow-2xl animate-in slide-in-from-right duration-500 flex flex-col">
            <header className="p-6 border-b flex items-center justify-between">
              <h3 className="text-lg font-black text-gray-900">Activity</h3>
              <button onClick={() => setShowNotifs(false)} className="p-2 text-gray-400 hover:text-gray-900"><X size={24} /></button>
            </header>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {notifs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-300 gap-4">
                  <Bell size={48} className="opacity-20" />
                  <p className="font-bold text-sm">Nothing to see here yet</p>
                </div>
              ) : (
                notifs.map(n => (
                  <div 
                    key={n.id} 
                    onClick={() => {
                      if (onNotificationClick) onNotificationClick(n);
                      setShowNotifs(false);
                    }}
                    className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex gap-3 group hover:border-indigo-200 transition-all cursor-pointer"
                  >
                    <div className="bg-white p-2.5 rounded-xl shadow-sm h-fit">
                      <Clock size={16} className="text-indigo-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-black text-gray-900 mb-0.5">{n.title}</p>
                      <p className="text-[10px] text-gray-500 font-medium leading-relaxed">{n.message}</p>
                      <p className="text-[8px] font-black text-indigo-400 uppercase mt-2 tracking-widest">
                        {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 p-6 pb-24">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-100 px-6 py-4 flex items-center justify-around z-40 shadow-[0_-10px_30px_rgba(0,0,0,0.03)] backdrop-blur-lg bg-white/95">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-1.5 transition-all group ${isActive ? 'scale-110' : 'opacity-40 hover:opacity-100'}`}
            >
              <div className={`p-2 rounded-xl transition-all ${isActive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-gray-900'}`}>
                <Icon size={20} />
              </div>
              <span className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'text-indigo-600' : 'text-gray-900'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default Layout;
