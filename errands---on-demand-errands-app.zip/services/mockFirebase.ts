
import { Errand, ErrandStatus, User, UserRole, Coordinates, Bid, AppNotification, NotificationType, ChatMessage, Transaction } from '../types';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const NAIROBI_LOCATIONS = [
  { name: 'Nairobi CBD', coords: { lat: -1.286389, lng: 36.817223 } },
  { name: 'Westlands', coords: { lat: -1.2635, lng: 36.8043 } },
  { name: 'Kilimani', coords: { lat: -1.2908, lng: 36.7877 } },
  { name: 'Upper Hill', coords: { lat: -1.3006, lng: 36.8172 } },
  { name: 'Karen', coords: { lat: -1.3200, lng: 36.7000 } },
  { name: 'Lavington', coords: { lat: -1.2750, lng: 36.7720 } },
  { name: 'Langata', coords: { lat: -1.3250, lng: 36.7900 } },
  { name: 'Parklands', coords: { lat: -1.2580, lng: 36.8200 } }
];

export const calculateDistance = (p1: Coordinates, p2: Coordinates) => {
  const R = 6371; // km
  const dLat = (p2.lat - p1.lat) * Math.PI / 180;
  const dLng = (p2.lng - p1.lng) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return parseFloat((R * c).toFixed(1));
};

interface MockUser extends User {
  password?: string;
}

class MockFirebaseService {
  private STORAGE_KEY_ERRANDS = 'errands_app_data_v4';
  private STORAGE_KEY_USERS = 'errands_app_users_v4';
  private STORAGE_KEY_AUTH = 'errands_app_auth_v4';
  private STORAGE_KEY_NOTIFS = 'errands_app_notifs_v4';

  private getUsers(): MockUser[] {
    const data = localStorage.getItem(this.STORAGE_KEY_USERS);
    if (!data) {
      const seedRunners: MockUser[] = NAIROBI_LOCATIONS.slice(0, 4).map((loc, i) => ({
        id: `runner_seed_${i}`,
        email: `runner${i}@test.com`.toLowerCase(),
        phone: `070000000${i}`,
        name: `Runner ${loc.name}`,
        role: UserRole.RUNNER,
        password: 'password',
        isVerified: true,
        avatar: `https://i.pravatar.cc/150?u=runner${i}`,
        createdAt: Date.now(),
        rating: 4.5 + (Math.random() * 0.5),
        ratingCount: 10 + i,
        isOnline: true,
        lastKnownLocation: loc.coords,
        balanceOnHold: 1500,
        balanceWithdrawn: 4500,
        address: 'Nairobi, Kenya',
        transactions: [
          {
            id: `tx_seed_${i}`,
            amount: 1500,
            type: 'earning',
            description: 'Starting Bonus',
            timestamp: Date.now() - 86400000,
          }
        ]
      }));
      this.saveUsers(seedRunners);
      return seedRunners;
    }
    return JSON.parse(data);
  }

  private saveUsers(users: MockUser[]) {
    localStorage.setItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
  }

  private getErrands(): Errand[] {
    const data = localStorage.getItem(this.STORAGE_KEY_ERRANDS);
    const errands: Errand[] = data ? JSON.parse(data) : [];
    return errands.map(e => ({ ...e, chat: e.chat || [] }));
  }

  private saveErrands(errands: Errand[]) {
    localStorage.setItem(this.STORAGE_KEY_ERRANDS, JSON.stringify(errands));
  }

  private getNotifs(): AppNotification[] {
    const data = localStorage.getItem(this.STORAGE_KEY_NOTIFS);
    return data ? JSON.parse(data) : [];
  }

  private saveNotifs(notifs: AppNotification[]) {
    localStorage.setItem(this.STORAGE_KEY_NOTIFS, JSON.stringify(notifs));
  }

  private createInternalNotification(userId: string, type: NotificationType, title: string, message: string, errandId: string) {
    const notifs = this.getNotifs();
    const newNotif: AppNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      userId,
      type,
      title,
      message,
      timestamp: Date.now(),
      read: false,
      errandId
    };
    this.saveNotifs([newNotif, ...notifs]);
  }

  async fetchNotifications(userId: string): Promise<AppNotification[]> {
    await delay(300);
    return this.getNotifs().filter(n => n.userId === userId);
  }

  async markNotificationsAsRead(userId: string): Promise<void> {
    const notifs = this.getNotifs();
    const updated = notifs.map(n => n.userId === userId ? { ...n, read: true } : n);
    this.saveNotifs(updated);
  }

  async getCurrentUser(): Promise<User | null> {
    const auth = localStorage.getItem(this.STORAGE_KEY_AUTH);
    if (!auth) return null;
    const basicAuth = JSON.parse(auth);
    const users = this.getUsers();
    const user = users.find(u => u.id === basicAuth.id);
    return user || null;
  }

  async getUserById(userId: string): Promise<User | null> {
    await delay(300);
    const users = this.getUsers();
    return users.find(u => u.id === userId) || null;
  }

  async getErrandById(errandId: string): Promise<Errand | null> {
    await delay(200);
    const errands = this.getErrands();
    return errands.find(e => e.id === errandId) || null;
  }

  async login(identifier: string, password: string): Promise<User> {
    await delay(800);
    const users = this.getUsers();
    const cleanId = identifier.trim().toLowerCase();
    const userFound = users.find(u => (u.email.toLowerCase() === cleanId || u.phone === cleanId));
    if (!userFound) throw new Error("No account found.");
    if (userFound.password !== password) throw new Error("Incorrect password.");
    const { password: _, ...userWithoutPassword } = userFound;
    localStorage.setItem(this.STORAGE_KEY_AUTH, JSON.stringify(userWithoutPassword));
    return userWithoutPassword;
  }

  async register(name: string, email: string, phone: string, password: string, role: UserRole): Promise<User> {
    await delay(1000);
    const users = this.getUsers();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone.trim();
    if (users.find(u => (cleanEmail && u.email.toLowerCase() === cleanEmail) || (cleanPhone && u.phone === cleanPhone))) {
      throw new Error(`Account already exists with this email or phone.`);
    }
    const loc = NAIROBI_LOCATIONS[Math.floor(Math.random() * NAIROBI_LOCATIONS.length)];
    const newUser: MockUser = {
      id: `user_${Math.random().toString(36).substr(2, 9)}`,
      email: cleanEmail,
      phone: cleanPhone,
      name: name.trim(),
      role,
      password,
      isVerified: true,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
      createdAt: Date.now(),
      rating: 5,
      ratingCount: 0,
      isOnline: role === UserRole.RUNNER,
      lastKnownLocation: loc.coords,
      balanceOnHold: 0,
      balanceWithdrawn: 0,
      address: '',
      transactions: []
    };
    this.saveUsers([...users, newUser]);
    const { password: _, ...cleanAuth } = newUser;
    localStorage.setItem(this.STORAGE_KEY_AUTH, JSON.stringify(cleanAuth));
    return newUser;
  }

  async logout() {
    localStorage.removeItem(this.STORAGE_KEY_AUTH);
  }

  async updateUserProfile(userId: string, updates: Partial<User>): Promise<User> {
    await delay(1000);
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index === -1) throw new Error("User not found");
    const updatedUser = { ...users[index], ...updates };
    users[index] = updatedUser;
    this.saveUsers(users);
    const auth = localStorage.getItem(this.STORAGE_KEY_AUTH);
    if (auth) {
      const currentAuth = JSON.parse(auth);
      if (currentAuth.id === userId) {
        const { password: _, ...cleanUser } = updatedUser;
        localStorage.setItem(this.STORAGE_KEY_AUTH, JSON.stringify(cleanUser));
      }
    }
    return updatedUser;
  }

  async fetchUserErrands(userId: string, role: UserRole): Promise<Errand[]> {
    await delay(500);
    const errands = this.getErrands();
    if (role === UserRole.REQUESTER) {
      return errands.filter(e => e.requesterId === userId && e.status !== ErrandStatus.CANCELLED);
    } else {
      return errands.filter(e => (e.runnerId === userId || e.bids.some(b => b.runnerId === userId)) && e.status !== ErrandStatus.CANCELLED);
    }
  }

  async fetchAvailableErrands(userId: string): Promise<Errand[]> {
    await delay(500);
    const errands = this.getErrands();
    return errands.filter(e => e.status === ErrandStatus.PENDING && e.requesterId !== userId);
  }

  async createErrand(errandData: Omit<Errand, 'id' | 'status' | 'createdAt' | 'runnerId' | 'bids' | 'requesterRating' | 'distanceKm' | 'chat'>): Promise<Errand> {
    await delay(1000);
    const users = this.getUsers();
    const user = users.find(u => u.id === errandData.requesterId);
    const distance = calculateDistance(errandData.pickupCoordinates, errandData.dropoffCoordinates);
    const newErrand: Errand = {
      ...errandData,
      id: `errand_${Date.now()}`,
      status: ErrandStatus.PENDING,
      runnerId: null,
      createdAt: Date.now(),
      bids: [],
      chat: [],
      requesterRating: user?.rating || 5,
      distanceKm: distance
    };
    const errands = this.getErrands();
    this.saveErrands([...errands, newErrand]);
    return newErrand;
  }

  async cancelErrand(errandId: string): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1 && errands[index].status === ErrandStatus.PENDING) {
      errands[index].status = ErrandStatus.CANCELLED;
      this.saveErrands(errands);
      return true;
    }
    return false;
  }

  async placeBid(errandId: string, runnerId: string, runnerName: string, price: number, eta?: string): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const users = this.getUsers();
    const runner = users.find(u => u.id === runnerId);
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1 && errands[index].status === ErrandStatus.PENDING) {
      errands[index].bids = (errands[index].bids || []).filter(b => b.runnerId !== runnerId);
      errands[index].bids.push({ runnerId, runnerName, price, timestamp: Date.now(), runnerRating: runner?.rating || 5, eta });
      this.saveErrands(errands);
      this.createInternalNotification(errands[index].requesterId, NotificationType.NEW_BID, "New Offer Received!", `${runnerName} offered Ksh ${price} to complete your task: ${errands[index].title}`, errandId);
      return true;
    }
    return false;
  }

  async instantAccept(errandId: string, runnerId: string, runnerName: string, price: number): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1 && errands[index].status === ErrandStatus.PENDING) {
      errands[index].status = ErrandStatus.ACCEPTED;
      errands[index].runnerId = runnerId;
      errands[index].acceptedPrice = price;
      errands[index].jobStartedAt = Date.now();
      errands[index].currentRunnerStatus = "Runner Claimed Task (Instant)";
      this.saveErrands(errands);
      this.createInternalNotification(errands[index].requesterId, NotificationType.BID_ACCEPTED, "Task Claimed!", `${runnerName} has accepted your task "${errands[index].title}" at your budget price.`, errandId);
      return true;
    }
    return false;
  }

  async acceptBid(errandId: string, runnerId: string, price: number): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1) {
      errands[index].status = ErrandStatus.ACCEPTED;
      errands[index].runnerId = runnerId;
      errands[index].acceptedPrice = price;
      errands[index].jobStartedAt = Date.now();
      errands[index].currentRunnerStatus = "Runner Accepted Task";
      this.saveErrands(errands);
      this.createInternalNotification(runnerId, NotificationType.BID_ACCEPTED, "Bid Accepted!", `Your offer for "${errands[index].title}" has been accepted. Start working!`, errandId);
      return true;
    }
    return false;
  }

  async updateRunnerStatus(errandId: string, statusText: string): Promise<boolean> {
    await delay(500);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1) {
      errands[index].currentRunnerStatus = statusText;
      this.saveErrands(errands);
      this.createInternalNotification(errands[index].requesterId, NotificationType.NEW_MESSAGE, "Status Update", `Update from runner: ${statusText}`, errandId);
      return true;
    }
    return false;
  }

  async submitForReview(errandId: string, comments: string): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1) {
      errands[index].status = ErrandStatus.VERIFYING;
      errands[index].runnerComments = comments;
      errands[index].currentRunnerStatus = "Task submitted for verification";
      this.saveErrands(errands);
      this.createInternalNotification(errands[index].requesterId, NotificationType.JOB_SUBMITTED, "Task Ready for Review", `The runner has marked "${errands[index].title}" as completed. Please verify.`, errandId);
      return true;
    }
    return false;
  }

  async completeErrand(errandId: string, signature: string, rating: number): Promise<boolean> {
    await delay(800);
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1) {
      const errand = errands[index];
      errand.status = ErrandStatus.COMPLETED;
      errand.signature = signature;
      errand.completedAt = Date.now();
      errand.runnerRatingGiven = rating;
      errand.currentRunnerStatus = "Task Completed & Verified";
      const runnerId = errand.runnerId;
      const acceptedPrice = errand.acceptedPrice || errand.budget;
      if (runnerId) {
        const users = this.getUsers();
        const runnerIndex = users.findIndex(u => u.id === runnerId);
        if (runnerIndex !== -1) {
          const runner = users[runnerIndex];
          const netEarnings = acceptedPrice * 0.95;
          runner.balanceOnHold = (runner.balanceOnHold || 0) + netEarnings;
          const currentRating = runner.rating || 5;
          const currentCount = runner.ratingCount || 0;
          runner.rating = ((currentRating * currentCount) + rating) / (currentCount + 1);
          runner.ratingCount = currentCount + 1;
          const newTx: Transaction = { id: `tx_${Date.now()}`, amount: netEarnings, type: 'earning', description: `Task Completion: ${errand.title}`, timestamp: Date.now(), errandId: errand.id };
          runner.transactions = [newTx, ...(runner.transactions || [])];
          this.saveUsers(users);
        }
        this.createInternalNotification(runnerId, NotificationType.JOB_COMPLETED, "Payment Released", `The requester signed off on "${errand.title}". Ksh ${acceptedPrice.toFixed(0)} credited.`, errandId);
      }
      this.saveErrands(errands);
      return true;
    }
    return false;
  }

  async withdrawBalance(userId: string): Promise<boolean> {
    await delay(1500);
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index !== -1) {
      const onHold = users[index].balanceOnHold || 0;
      if (onHold <= 0) return false;
      users[index].balanceWithdrawn = (users[index].balanceWithdrawn || 0) + onHold;
      users[index].balanceOnHold = 0;
      const newTx: Transaction = { id: `tx_w_${Date.now()}`, amount: onHold, type: 'withdrawal', description: `M-Pesa Withdrawal`, timestamp: Date.now() };
      users[index].transactions = [newTx, ...(users[index].transactions || [])];
      this.saveUsers(users);
      return true;
    }
    return false;
  }

  async sendChatMessage(errandId: string, senderId: string, senderName: string, text: string): Promise<boolean> {
    const errands = this.getErrands();
    const index = errands.findIndex(e => e.id === errandId);
    if (index !== -1) {
      const errand = errands[index];
      const newMessage: ChatMessage = { id: `msg_${Date.now()}`, senderId, senderName, text, timestamp: Date.now() };
      errand.chat = [...(errand.chat || []), newMessage];
      this.saveErrands(errands);
      const receiverId = senderId === errand.requesterId ? errand.runnerId : errand.requesterId;
      if (receiverId) {
        this.createInternalNotification(receiverId, NotificationType.NEW_MESSAGE, `Message from ${senderName}`, text, errandId);
      }
      return true;
    }
    return false;
  }
}

export const firebaseService = new MockFirebaseService();
