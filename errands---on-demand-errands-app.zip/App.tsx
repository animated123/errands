
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Plus, MapPin, DollarSign, Calendar, Briefcase, 
  CheckCircle, Star, Camera, Navigation, Clock, Map as MapIcon, 
  List, ChevronLeft, ChevronRight, LogOut, TrendingUp, Search, Info,
  Phone, Mail, User as UserIcon, Globe, MapPinned, UserCheck, Loader2,
  ArrowRight, CreditCard, ShieldCheck, X, Timer, BellRing, Target,
  Wallet, Landmark, Receipt, Trash2, MessageSquare, Send, Zap, ShoppingBag,
  Package, Bike, Flag, AlertCircle, AlertTriangle, Filter, ChevronDown, Check, Edit2, Save, RefreshCw, History, ArrowUpRight, ArrowDownLeft
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { User, UserRole, Errand, ErrandStatus, Coordinates, Bid, AppNotification, NotificationType, ChatMessage, Transaction } from './types';
import { firebaseService, calculateDistance } from './services/mockFirebase';
import Layout from './components/Layout';
import ErrandCard from './components/ErrandCard';
import Logo from './components/Logo';

// --- Utility: Format Duration ---
const formatDuration = (ms: number) => {
  if (!ms || ms < 0) return "0s";
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
};

// --- Toast Component ---
const Toast: React.FC<{ notif: AppNotification, onClose: () => void }> = ({ notif, onClose }) => {
  useEffect(() => {
    const t = setTimeout(onClose, 5000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <div className="fixed top-24 left-4 right-4 z-[100] bg-gray-900/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border border-white/10 flex items-start gap-3 animate-in slide-in-from-top-4 duration-500">
      <div className="bg-indigo-500 p-2 rounded-xl shadow-lg shadow-indigo-500/20">
        <BellRing size={18} className="animate-bounce" />
      </div>
      <div className="flex-1">
        <h5 className="font-bold text-xs mb-0.5">{notif.title}</h5>
        <p className="text-[10px] text-gray-300 font-medium line-clamp-2">{notif.message}</p>
      </div>
      <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors"><X size={16} /></button>
    </div>
  );
};

// --- Error Banner Component ---
const ErrorBanner: React.FC<{ message: string, onClose: () => void }> = ({ message, onClose }) => {
  return (
    <div className="fixed top-24 left-4 right-4 z-[110] bg-red-50 border-2 border-red-200 text-red-900 p-4 rounded-2xl shadow-2xl flex items-start gap-3 animate-in slide-in-from-top-4 duration-500 ring-4 ring-red-500/10">
      <div className="bg-red-500 p-2 rounded-xl text-white">
        <AlertTriangle size={18} />
      </div>
      <div className="flex-1">
        <h5 className="font-black text-[10px] uppercase tracking-widest mb-0.5">Alert</h5>
        <p className="text-xs font-bold leading-relaxed">{message}</p>
      </div>
      <button onClick={onClose} className="text-red-300 hover:text-red-900 transition-colors"><X size={16} /></button>
    </div>
  );
};

// --- Signature Pad Component ---
const SignaturePad: React.FC<{ onSave: (data: string) => void }> = ({ onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.strokeStyle = '#4f46e5';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
  }, []);

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? (e as React.TouchEvent).touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? (e as React.TouchEvent).touches[0].clientY : (e as React.MouseEvent).clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => { 
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsDrawing(true); 
    const { x, y } = getPos(e); 
    ctx.beginPath(); 
    ctx.moveTo(x, y); 
  };

  const move = (e: React.MouseEvent | React.TouchEvent) => { 
    if (!isDrawing) return; 
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { x, y } = getPos(e); 
    ctx.lineTo(x, y); 
    ctx.stroke(); 
  };
  
  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    onSave(canvas.toDataURL());
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  return (
    <div className="space-y-2">
      <div className="bg-white border-2 border-dashed border-gray-200 rounded-2xl p-0.5 overflow-hidden">
        <canvas 
          ref={canvasRef} 
          width={320} 
          height={120} 
          onMouseDown={start} 
          onMouseMove={move} 
          onMouseUp={() => setIsDrawing(false)} 
          onTouchStart={start} 
          onTouchMove={move} 
          onTouchEnd={() => setIsDrawing(false)} 
          className="w-full bg-white rounded-xl touch-none cursor-crosshair" 
        />
      </div>
      <div className="flex justify-between items-center px-1">
        <button type="button" onClick={clearCanvas} className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Clear</button>
        <button type="button" onClick={handleSave} className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">Confirm Signature</button>
      </div>
    </div>
  );
};

// --- Chat View ---
const ChatView: React.FC<{ errand: Errand, user: User, onClose: () => void, onRefresh: () => void }> = ({ errand, user, onClose, onRefresh }) => {
  const [msg, setMsg] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [errand.chat]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msg.trim()) return;
    const text = msg.trim();
    setMsg('');
    await firebaseService.sendChatMessage(errand.id, user.id, user.name, text);
    onRefresh();
  };

  return (
    <div className="fixed inset-0 bg-white z-[70] flex flex-col max-w-md mx-auto animate-in slide-in-from-bottom duration-300">
      <header className="p-4 border-b flex items-center gap-3 sticky top-0 bg-white/90 backdrop-blur-md z-10">
        <button onClick={onClose} className="p-2 -ml-2 text-gray-400"><ChevronLeft size={20} /></button>
        <div>
          <h3 className="font-bold text-gray-900 text-sm">Task Chat</h3>
          <p className="text-[10px] font-black uppercase text-indigo-600 tracking-tighter truncate max-w-[200px]">{errand.title}</p>
        </div>
      </header>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/50">
        {errand.chat.map((m) => {
          const isMe = m.senderId === user.id;
          return (
            <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[80%] p-3.5 rounded-2xl text-[13px] font-medium ${isMe ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-gray-700 rounded-tl-none border border-gray-100 shadow-sm'}`}>
                {m.text}
              </div>
              <span className="text-[8px] font-black text-gray-400 mt-1 uppercase px-1">
                {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          );
        })}
      </div>
      <form onSubmit={handleSend} className="p-4 border-t bg-white flex gap-2">
        <input 
          type="text" 
          value={msg} 
          onChange={(e) => setMsg(e.target.value)}
          placeholder="Type message..." 
          className="flex-1 p-3.5 bg-transparent border-b border-gray-200 font-bold text-xs outline-none focus:border-indigo-600 transition-all text-gray-900 placeholder:text-gray-300 rounded-none"
        />
        <button type="submit" disabled={!msg.trim()} className="w-12 h-12 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg active:scale-95 disabled:opacity-50 transition-all">
          <Send size={20} />
        </button>
      </form>
    </div>
  );
};

// --- Location Autocomplete Component ---
const LocationAutocomplete: React.FC<{ 
  label: string, 
  icon: React.ReactNode, 
  placeholder: string,
  onSelect: (loc: {name: string, coords: Coordinates}) => void,
  value?: string
}> = ({ label, icon, placeholder, onSelect, value = "" }) => {
  const [query, setQuery] = useState(value);
  const [suggestions, setSuggestions] = useState<{name: string, coords: Coordinates}[]>([]);
  const [loading, setLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const isSelected = useRef(false);

  useEffect(() => { 
    setQuery(value); 
    isSelected.current = !!value; 
  }, [value]);

  const fetchResults = async (q: string) => {
    if (!q || q.length < 3 || isSelected.current) {
        setSuggestions([]);
        setShowDropdown(false);
        return;
    }
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Find popular business or landmark locations in Nairobi, Kenya matching: "${q}". Return as a raw JSON array of objects with "name", "lat", "lng". Max 4 results.`,
      });
      const text = response.text || "";
      const match = text.match(/\[.*\]/s);
      if (match) {
        const data = JSON.parse(match[0]);
        const results = data.map((d: any) => ({ name: d.name, coords: { lat: d.lat, lng: d.lng } }));
        setSuggestions(results);
        setShowDropdown(results.length > 0);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(() => {
      fetchResults(query);
    }, 600);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div className="space-y-1 relative">
      <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 flex items-center gap-1">
        {icon} {label}
      </label>
      <div className="relative">
        <input 
          type="text" 
          value={query}
          onChange={(e) => { setQuery(e.target.value); isSelected.current = false; }}
          placeholder={placeholder}
          className="w-full p-3.5 bg-transparent border-b border-gray-200 font-bold text-xs focus:border-indigo-600 transition-all outline-none text-gray-900 rounded-none"
        />
        {loading && <Loader2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-indigo-400" />}
      </div>
      {showDropdown && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-100 shadow-xl rounded-xl z-[100] overflow-hidden">
          {suggestions.map((s, i) => (
            <button key={i} onClick={() => { setQuery(s.name); isSelected.current = true; setShowDropdown(false); onSelect(s); }} className="w-full p-3 text-left hover:bg-gray-50 flex items-center gap-3 border-b last:border-0">
              <MapPin size={14} className="text-gray-400" />
              <span className="text-[11px] font-bold text-gray-700">{s.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

// --- Main App Component ---
const App: React.FC = () => {
  const [auth, setAuth] = useState<{ user: User | null; isAuthenticated: boolean; loading: boolean }>({ user: null, isAuthenticated: false, loading: true });
  const [activeTab, setActiveTab] = useState('dashboard');
  const [errands, setErrands] = useState<Errand[]>([]);
  const [availableErrands, setAvailableErrands] = useState<Errand[]>([]);
  const [selectedErrand, setSelectedErrand] = useState<Errand | null>(null);
  const [showAuthForm, setShowAuthForm] = useState<'login' | 'register'>('login');
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', password: '', role: UserRole.REQUESTER });
  const [newErrand, setNewErrand] = useState({ title: '', description: '', budget: 500, deadline: new Date(Date.now() + 86400000).toISOString().split('T')[0], pickup: '', dropoff: '', pickupCoords: {lat:0,lng:0}, dropoffCoords: {lat:0,lng:0} });
  const [bidPrice, setBidPrice] = useState(0);
  const [bidEta, setBidEta] = useState('');
  const [showChat, setShowChat] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notifToast, setNotifToast] = useState<AppNotification | null>(null);
  const [verifyRating, setVerifyRating] = useState(5);
  const [confirmCancel, setConfirmCancel] = useState(false);

  // Profile Edit States
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileEditData, setProfileEditData] = useState({ name: '', phone: '', address: '', avatar: '' });

  const intervalRef = useRef<number | null>(null);

  // Guard against re-popping closed errands
  const selectedErrandIdRef = useRef<string | null>(null);
  useEffect(() => {
    selectedErrandIdRef.current = selectedErrand ? selectedErrand.id : null;
    if (selectedErrand) {
      setBidPrice(selectedErrand.budget);
      setBidEta('');
    }
  }, [selectedErrand]);

  const refreshData = useCallback(async () => {
    if (!auth.user || !auth.isAuthenticated) return;
    try {
      const list = await firebaseService.fetchUserErrands(auth.user.id, auth.user.role);
      setErrands(list);

      if (auth.user.role === UserRole.RUNNER) {
        const available = await firebaseService.fetchAvailableErrands(auth.user.id);
        setAvailableErrands(available);
      }
      
      const currentId = selectedErrandIdRef.current;
      if (currentId) {
        const updated = await firebaseService.getErrandById(currentId);
        if (updated && selectedErrandIdRef.current === updated.id) {
          setSelectedErrand(updated);
        }
      }
      
      const updatedUser = await firebaseService.getUserById(auth.user.id);
      if (updatedUser) {
        setAuth(prev => {
          if (!prev.isAuthenticated || !prev.user) return prev;
          return { ...prev, user: updatedUser };
        });
      }
    } catch (e) {
      console.error("Refresh failed", e);
    }
  }, [auth.user, auth.isAuthenticated]);

  useEffect(() => {
    firebaseService.getCurrentUser().then(user => {
      if (user) setAuth({ user, isAuthenticated: true, loading: false });
      else setAuth({ user: null, isAuthenticated: false, loading: false });
    });
  }, []);

  useEffect(() => {
    if (auth.isAuthenticated) {
      refreshData();
      const int = window.setInterval(refreshData, 5000);
      intervalRef.current = int;
      return () => {
        if (intervalRef.current) {
          window.clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      };
    }
  }, [auth.isAuthenticated, refreshData]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuth(prev => ({ ...prev, loading: true }));
    setError(null);
    try {
      if (showAuthForm === 'login') {
        const user = await firebaseService.login(formData.email, formData.password);
        setAuth({ user, isAuthenticated: true, loading: false });
      } else {
        const user = await firebaseService.register(formData.name, formData.email, formData.phone, formData.password, formData.role);
        setAuth({ user, isAuthenticated: true, loading: false });
      }
    } catch (err: any) {
      setError(err.message);
      setAuth(prev => ({ ...prev, loading: false }));
    }
  };

  const handleLogout = useCallback(() => {
    if (intervalRef.current) {
        window.clearInterval(intervalRef.current);
        intervalRef.current = null;
    }
    firebaseService.logout();
    setAuth({ user: null, isAuthenticated: false, loading: false });
    setSelectedErrand(null);
    setActiveTab('dashboard');
  }, []);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.user) return;
    try {
      await firebaseService.updateUserProfile(auth.user.id, profileEditData);
      setIsEditingProfile(false);
      refreshData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const startEditing = () => {
    if (auth.user) {
      setProfileEditData({
        name: auth.user.name,
        phone: auth.user.phone || '',
        address: auth.user.address || '',
        avatar: auth.user.avatar || ''
      });
      setIsEditingProfile(true);
    }
  };

  const refreshAvatar = () => {
    const seed = Math.random().toString(36).substring(7);
    const newAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(profileEditData.name || 'User')}&background=random&seed=${seed}`;
    setProfileEditData({ ...profileEditData, avatar: newAvatar });
  };

  const handlePostErrand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.user) return;
    try {
      await firebaseService.createErrand({
        title: newErrand.title,
        description: newErrand.description,
        budget: Number(newErrand.budget),
        deadline: newErrand.deadline,
        pickupLocation: newErrand.pickup,
        pickupCoordinates: newErrand.pickupCoords,
        dropoffLocation: newErrand.dropoff,
        dropoffCoordinates: newErrand.dropoffCoords,
        requesterId: auth.user.id,
        requesterName: auth.user.name,
      });
      setNewErrand({ title: '', description: '', budget: 500, deadline: new Date(Date.now() + 86400000).toISOString().split('T')[0], pickup: '', dropoff: '', pickupCoords: {lat:0,lng:0}, dropoffCoords: {lat:0,lng:0} });
      setActiveTab('dashboard');
      refreshData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCancelErrand = async () => {
    if (!selectedErrand) return;
    const success = await firebaseService.cancelErrand(selectedErrand.id);
    if (success) {
      setConfirmCancel(false);
      setSelectedErrand(null);
      refreshData();
    } else {
      setError("Failed to cancel errand.");
    }
  };

  const handlePlaceBid = async () => {
    if (!auth.user || !selectedErrand) return;
    if (bidPrice <= 0) {
      setError("Please enter a valid price.");
      return;
    }
    const success = await firebaseService.placeBid(selectedErrand.id, auth.user.id, auth.user.name, bidPrice, bidEta);
    if (success) {
      refreshData();
    } else {
      setError("Failed to submit bid.");
    }
  };

  const handleInstantAccept = async () => {
    if (!auth.user || !selectedErrand) return;
    const success = await firebaseService.instantAccept(selectedErrand.id, auth.user.id, auth.user.name, selectedErrand.budget);
    if (success) {
      refreshData();
    } else {
      setError("Failed to accept task.");
    }
  };

  const handleAcceptBid = async (bid: Bid) => {
    if (!selectedErrand) return;
    await firebaseService.acceptBid(selectedErrand.id, bid.runnerId, bid.price);
    refreshData();
  };

  const handleCompleteErrand = async (rating: number, signature: string) => {
    if (!selectedErrand) return;
    await firebaseService.completeErrand(selectedErrand.id, signature, rating);
    refreshData();
    setSelectedErrand(null);
  };

  const handleNotificationClick = async (notif: AppNotification) => {
    if (notif.errandId) {
       const err = await firebaseService.getErrandById(notif.errandId);
       if (err) {
         setSelectedErrand(err);
         if (err.status === ErrandStatus.PENDING && auth.user?.role === UserRole.RUNNER) {
           setActiveTab('find');
         } else {
           setActiveTab('dashboard');
         }
       }
    }
  };

  if (auth.loading) return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-12 text-center">
      <Logo size={80} className="mb-8 animate-pulse text-indigo-600" />
      <Loader2 className="animate-spin text-indigo-600 mb-4" size={32} />
      <p className="font-black text-[10px] uppercase tracking-[0.2em] text-gray-400">Booting Protocol...</p>
    </div>
  );

  if (!auth.isAuthenticated) return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto relative overflow-hidden">
      <div className="p-8 pt-16 flex-1 flex flex-col justify-center">
        <div className="flex items-center gap-4 mb-8">
           <div className="w-14 h-14 bg-gray-900 rounded-2xl flex items-center justify-center shadow-xl shadow-gray-200">
             <Logo size={32} color="white" />
           </div>
           <div>
             <h1 className="text-3xl font-black text-gray-900 tracking-tighter">Errands</h1>
             <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Digital Runner Network</p>
           </div>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {showAuthForm === 'register' && (
            <>
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Full Name</label>
                <input required type="text" placeholder="John Doe" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 placeholder:text-gray-300 rounded-none" />
              </div>
              <div className="flex gap-2 p-1 bg-gray-100 rounded-2xl">
                 <button type="button" onClick={() => setFormData({...formData, role: UserRole.REQUESTER})} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${formData.role === UserRole.REQUESTER ? 'bg-white shadow-md text-indigo-600' : 'text-gray-400'}`}>Requester</button>
                 <button type="button" onClick={() => setFormData({...formData, role: UserRole.RUNNER})} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${formData.role === UserRole.RUNNER ? 'bg-white shadow-md text-indigo-600' : 'text-gray-400'}`}>Runner</button>
              </div>
            </>
          )}
          
          <div className="space-y-1">
            <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">
              {showAuthForm === 'login' ? 'Email or Phone' : 'Email Address'}
            </label>
            <input required type="text" placeholder={showAuthForm === 'login' ? "Email or Phone" : "name@email.com"} value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 placeholder:text-gray-300 rounded-none" />
          </div>

          {showAuthForm === 'register' && (
            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Phone Number</label>
              <input required type="tel" placeholder="0700 000 000" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 placeholder:text-gray-300 rounded-none" />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Password</label>
            <input required type="password" placeholder="••••••••" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 placeholder:text-gray-300 rounded-none" />
          </div>

          <button type="submit" className="w-full py-5 bg-gray-900 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-gray-200 active:scale-95 transition-all mt-6 flex items-center justify-center gap-2">
            {showAuthForm === 'login' ? 'Access Account' : 'Initialize Profile'} <ArrowRight size={16} />
          </button>
        </form>

        <p className="text-center mt-8 text-[11px] font-bold text-gray-400">
          {showAuthForm === 'login' ? "New to the network?" : "Already verified?"}
          <button onClick={() => { setShowAuthForm(showAuthForm === 'login' ? 'register' : 'login'); setError(null); }} className="ml-2 text-indigo-600 font-black uppercase tracking-widest">
            {showAuthForm === 'login' ? 'Join Now' : 'Sign In'}
          </button>
        </p>
      </div>
      {error && <ErrorBanner message={error} onClose={() => setError(null)} />}
    </div>
  );

  const isRunner = auth.user?.role === UserRole.RUNNER;

  return (
    <Layout 
      user={auth.user} 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      onLogout={handleLogout}
      onNotificationClick={handleNotificationClick}
    >
      {notifToast && <Toast notif={notifToast} onClose={() => setNotifToast(null)} />}
      {error && <ErrorBanner message={error} onClose={() => setError(null)} />}

      {/* Confirmation Dialog for Cancellation */}
      {confirmCancel && (
        <div className="fixed inset-0 z-[100] bg-gray-900/60 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] p-8 w-full max-w-xs shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 bg-red-50 text-red-500 rounded-3xl flex items-center justify-center mb-6 mx-auto">
              <AlertCircle size={32} />
            </div>
            <h3 className="text-lg font-black text-gray-900 text-center mb-2">Cancel Errand?</h3>
            <p className="text-xs font-medium text-gray-500 text-center mb-8">This action will remove the task from the marketplace and cannot be undone.</p>
            <div className="flex flex-col gap-3">
              <button onClick={handleCancelErrand} className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-red-100 active:scale-95 transition-all">Confirm Cancellation</button>
              <button onClick={() => setConfirmCancel(false)} className="w-full py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">Keep Errand</button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'dashboard' && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 mb-3">
                <Zap size={20} />
              </div>
              <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Ongoing Tasks</p>
              <h4 className="text-2xl font-black text-gray-900">{errands.filter(e => e.status !== ErrandStatus.COMPLETED).length}</h4>
            </div>
            <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
              <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 mb-3">
                <TrendingUp size={20} />
              </div>
              <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Completed</p>
              <h4 className="text-2xl font-black text-gray-900">{errands.filter(e => e.status === ErrandStatus.COMPLETED).length}</h4>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-gray-900">Activity Log</h2>
            <button className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">View History</button>
          </div>

          <div className="space-y-4">
            {errands.length === 0 ? (
              <div className="bg-gray-100/50 rounded-3xl p-12 flex flex-col items-center justify-center text-center gap-4 border-2 border-dashed border-gray-200">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                  <Package size={32} className="text-gray-300" />
                </div>
                <div>
                  <p className="font-black text-gray-900 text-sm">No activity found</p>
                  <p className="text-[10px] text-gray-400 font-bold max-w-[160px] mx-auto mt-1">Start by {isRunner ? 'finding' : 'posting'} an errand today.</p>
                </div>
              </div>
            ) : (
              errands.map(e => (
                <ErrandCard key={e.id} errand={e} onClick={setSelectedErrand} />
              ))
            )}
          </div>
        </div>
      )}

      {activeTab === 'create' && (
        <div className="animate-in slide-in-from-bottom duration-500">
          <header className="mb-8">
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">Deploy Errand</h2>
            <p className="text-xs font-bold text-gray-400 mt-1">Fill in the task logistics for our runner network.</p>
          </header>
          <form onSubmit={handlePostErrand} className="space-y-6">
            <div className="space-y-4">
               <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Task Title</label>
                  <input required value={newErrand.title} onChange={e => setNewErrand({...newErrand, title: e.target.value})} placeholder="e.g. Urgent Pharmacy Delivery" className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 rounded-none" />
               </div>
               <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Description</label>
                  <textarea rows={3} value={newErrand.description} onChange={e => setNewErrand({...newErrand, description: e.target.value})} placeholder="Provide specific instructions..." className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all resize-none text-gray-900 rounded-none" />
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Max Budget (Ksh)</label>
                    <input type="number" value={newErrand.budget} onChange={e => setNewErrand({...newErrand, budget: Number(e.target.value)})} className="w-full p-4 bg-transparent border-b border-gray-200 font-black text-sm outline-none focus:border-indigo-600 text-gray-900 rounded-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Deadline Date</label>
                    <input type="date" value={newErrand.deadline} onChange={e => setNewErrand({...newErrand, deadline: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none text-gray-900 rounded-none" />
                  </div>
               </div>
               <LocationAutocomplete label="Pickup Terminal" placeholder="Where should we collect from?" icon={<ShoppingBag size={10} />} onSelect={(loc) => setNewErrand({...newErrand, pickup: loc.name, pickupCoords: loc.coords})} />
               <LocationAutocomplete label="Dropoff Destination" placeholder="Target coordinates for delivery" icon={<MapPin size={10} />} onSelect={(loc) => setNewErrand({...newErrand, dropoff: loc.name, dropoffCoords: loc.coords})} />
            </div>
            <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-indigo-100 active:scale-95 transition-all mt-6 flex items-center justify-center gap-2">
              Broadcast Task <Globe size={16} />
            </button>
          </form>
        </div>
      )}

      {activeTab === 'find' && (
        <div className="space-y-6 animate-in slide-in-from-right duration-500">
           <header className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-black text-gray-900 tracking-tight">Marketplace</h2>
                <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Open Opportunities</p>
              </div>
              <button className="p-3 bg-white border border-gray-100 rounded-xl text-indigo-600 shadow-sm"><Filter size={20} /></button>
           </header>
           <div className="space-y-4">
              {availableErrands.filter(e => e.status === ErrandStatus.PENDING).length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-gray-100 shadow-sm flex flex-col items-center gap-4">
                   <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-200"><Search size={40} /></div>
                   <p className="font-black text-gray-900 text-sm uppercase tracking-widest">No Open Tasks</p>
                   <p className="text-[10px] text-gray-400 font-bold">New errands will appear here as they are posted in the network.</p>
                </div>
              ) : (
                availableErrands.filter(e => e.status === ErrandStatus.PENDING).map(e => (
                  <ErrandCard key={e.id} errand={e} onClick={setSelectedErrand} />
                ))
              )}
           </div>
        </div>
      )}

      {activeTab === 'active' && (
        <div className="space-y-8 animate-in slide-in-from-left duration-500">
          {!isEditingProfile ? (
            <>
              <div className="flex flex-col items-center pt-8">
                <div className="relative mb-4">
                  <img src={auth.user?.avatar} alt="Avatar" className="w-24 h-24 rounded-[2.5rem] border-4 border-white shadow-2xl" />
                  <button onClick={startEditing} className="absolute -bottom-1 -right-1 w-8 h-8 bg-indigo-600 text-white rounded-xl border-4 border-white flex items-center justify-center shadow-lg active:scale-90 transition-all">
                    <Edit2 size={12} />
                  </button>
                </div>
                <h3 className="text-xl font-black text-gray-900">{auth.user?.name}</h3>
                
                <div className="flex flex-col items-center gap-1.5 mt-1">
                  <div className="flex items-center gap-1.5 bg-indigo-50 px-3 py-1 rounded-full">
                    <Mail size={12} className="text-indigo-600" />
                    <span className="text-[11px] font-black text-indigo-700">{auth.user?.email}</span>
                    <CheckCircle size={10} className="text-indigo-400" />
                  </div>
                  <div className="flex items-center gap-1.5 bg-amber-50 px-3 py-1 rounded-full">
                    <Star size={12} className="text-amber-500 fill-amber-500" />
                    <span className="text-[11px] font-black text-amber-700">{auth.user?.rating.toFixed(1)} <span className="text-amber-300 ml-0.5">({auth.user?.ratingCount})</span></span>
                  </div>
                  {auth.user?.address && (
                    <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400">
                      <MapPin size={10} /> {auth.user.address}
                    </div>
                  )}
                </div>
              </div>
              
              {isRunner && (
                <>
                  <div className="bg-gray-900 rounded-[2.5rem] p-6 text-white shadow-2xl relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                     <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 mb-2">Available Balance</p>
                     <h4 className="text-4xl font-black tracking-tight mb-8">Ksh {(auth.user?.balanceOnHold || 0).toLocaleString()}</h4>
                     <div className="flex gap-3">
                       <button onClick={async () => {
                         if (auth.user) {
                           await firebaseService.withdrawBalance(auth.user.id);
                           refreshData();
                         }
                       }} className="flex-1 py-4 bg-white text-gray-900 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">
                         Withdraw Now <CreditCard size={14} />
                       </button>
                     </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between px-1">
                      <h4 className="text-[10px] font-black uppercase text-gray-400 tracking-[0.2em]">Financial Log</h4>
                      <History size={14} className="text-gray-300" />
                    </div>
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {auth.user?.transactions && auth.user.transactions.length > 0 ? (
                        auth.user.transactions.map(tx => (
                          <div key={tx.id} className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center justify-between group">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${tx.type === 'earning' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                {tx.type === 'earning' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                              </div>
                              <div>
                                <p className="text-[11px] font-black text-gray-800 leading-tight truncate max-w-[150px]">{tx.description}</p>
                                <p className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter">{new Date(tx.timestamp).toLocaleDateString()} at {new Date(tx.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                              </div>
                            </div>
                            <div className={`text-xs font-black ${tx.type === 'earning' ? 'text-emerald-600' : 'text-amber-600'}`}>
                              {tx.type === 'earning' ? '+' : '-'} {tx.amount.toLocaleString()}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-[10px] text-gray-400 font-bold text-center py-4 italic">No financial movements recorded.</p>
                      )}
                    </div>
                  </div>
                </>
              )}

              <div className="space-y-3">
                <button onClick={startEditing} className="w-full p-5 bg-white border border-gray-100 rounded-3xl flex items-center justify-between group shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600"><UserIcon size={18} /></div>
                    <span className="text-xs font-black text-gray-900 uppercase tracking-widest">Update Profile</span>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-indigo-600 transition-colors" />
                </button>
                <button onClick={handleLogout} className="w-full p-5 bg-red-50/50 border border-red-100 rounded-3xl flex items-center justify-between group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center text-red-600"><LogOut size={18} /></div>
                    <span className="text-xs font-black text-red-600 uppercase tracking-widest">Terminate Session</span>
                  </div>
                  <ChevronRight size={18} className="text-red-200" />
                </button>
              </div>
            </>
          ) : (
            <div className="animate-in slide-in-from-bottom duration-500 pt-8">
              <div className="flex items-center justify-between mb-8">
                <button onClick={() => setIsEditingProfile(false)} className="p-2 -ml-2 text-gray-400"><X size={24} /></button>
                <h2 className="text-sm font-black text-gray-900 uppercase tracking-widest">Edit Profile</h2>
                <div className="w-10"></div>
              </div>
              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div className="flex flex-col items-center mb-8">
                  <div className="relative">
                    <img src={profileEditData.avatar} alt="Edit Avatar" className="w-24 h-24 rounded-[2.5rem] border-4 border-indigo-600 shadow-2xl mb-4" />
                    <button type="button" onClick={refreshAvatar} className="absolute -bottom-1 -right-1 w-8 h-8 bg-indigo-600 text-white rounded-xl border-4 border-white flex items-center justify-center shadow-lg active:rotate-180 transition-all">
                      <RefreshCw size={12} />
                    </button>
                  </div>
                </div>
                <div className="space-y-4">
                   <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Full Name</label>
                      <input required value={profileEditData.name} onChange={e => setProfileEditData({...profileEditData, name: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 rounded-none" />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Phone Number</label>
                      <input required value={profileEditData.phone} onChange={e => setProfileEditData({...profileEditData, phone: e.target.value})} className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 rounded-none" />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1 opacity-50">Email (Verified)</label>
                      <input readOnly disabled value={auth.user?.email} className="w-full p-4 bg-transparent border-b border-gray-100 font-bold text-sm text-gray-400 rounded-none outline-none cursor-not-allowed" />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-1">Base Address</label>
                      <input value={profileEditData.address} onChange={e => setProfileEditData({...profileEditData, address: e.target.value})} placeholder="e.g. Kilimani, Nairobi" className="w-full p-4 bg-transparent border-b border-gray-200 font-bold text-sm outline-none focus:border-indigo-600 transition-all text-gray-900 rounded-none" />
                   </div>
                </div>
                <div className="flex gap-3 mt-12">
                   <button type="button" onClick={() => setIsEditingProfile(false)} className="flex-1 py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">Discard</button>
                   <button type="submit" className="flex-[2] py-4 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">Save Changes <Save size={14} /></button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {selectedErrand && (
        <div className="fixed inset-0 bg-white z-[60] flex flex-col max-w-md mx-auto animate-in slide-in-from-right duration-300">
           <header className="p-6 border-b flex items-center justify-between sticky top-0 bg-white/90 backdrop-blur-md z-10">
              <button onClick={() => setSelectedErrand(null)} className="p-2 -ml-2 text-gray-400"><ChevronLeft size={24} /></button>
              <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest">Errand Blueprint</h3>
              <div className="w-10"></div>
           </header>
           <div className="flex-1 overflow-y-auto p-6 space-y-8 pb-32">
              <section>
                <div className="flex items-start justify-between mb-2">
                   <h2 className="text-2xl font-black text-gray-900 leading-tight flex-1">{selectedErrand.title}</h2>
                   <div className="bg-indigo-600 text-white px-3 py-1.5 rounded-xl font-black text-xs shadow-lg shadow-indigo-100">Ksh {selectedErrand.acceptedPrice || selectedErrand.budget}</div>
                </div>
                <p className="text-xs font-medium text-gray-500 leading-relaxed">{selectedErrand.description}</p>
              </section>
              <section className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-4">Current Progress</p>
                <div className="flex items-center gap-4 mb-4">
                   <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg ${selectedErrand.status === ErrandStatus.COMPLETED ? 'bg-emerald-500 shadow-emerald-100' : 'bg-indigo-600 shadow-indigo-100'}`}>
                      {selectedErrand.status === ErrandStatus.PENDING && <Clock size={24} />}
                      {selectedErrand.status === ErrandStatus.ACCEPTED && <Bike size={24} />}
                      {selectedErrand.status === ErrandStatus.VERIFYING && <ShieldCheck size={24} />}
                      {selectedErrand.status === ErrandStatus.COMPLETED && <CheckCircle size={24} />}
                   </div>
                   <div>
                      <h4 className="text-sm font-black text-gray-900 uppercase tracking-tighter">{selectedErrand.status}</h4>
                      <p className="text-[10px] font-bold text-gray-400">{selectedErrand.currentRunnerStatus || 'Awaiting runner response...'}</p>
                   </div>
                </div>
              </section>
              <section className="grid grid-cols-2 gap-4">
                 <div className="space-y-1">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Distance</p>
                    <div className="flex items-center gap-2 font-black text-xs text-gray-900"><Globe size={14} className="text-indigo-400" /> {selectedErrand.distanceKm} KM</div>
                 </div>
                 <div className="space-y-1">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">ETA</p>
                    <div className="flex items-center gap-2 font-black text-xs text-gray-900"><Timer size={14} className="text-indigo-400" /> {selectedErrand.eta || 'TBD'}</div>
                 </div>
              </section>
              <section className="space-y-4">
                 <div className="flex items-start gap-4">
                    <div className="w-1 bg-emerald-500 h-10 rounded-full mt-1"></div>
                    <div>
                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Pickup Location</p>
                      <p className="text-xs font-bold text-gray-800">{selectedErrand.pickupLocation}</p>
                    </div>
                 </div>
                 <div className="flex items-start gap-4">
                    <div className="w-1 bg-red-500 h-10 rounded-full mt-1"></div>
                    <div>
                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Dropoff Location</p>
                      <p className="text-xs font-bold text-gray-800">{selectedErrand.dropoffLocation}</p>
                    </div>
                 </div>
              </section>

              {isRunner && selectedErrand.status === ErrandStatus.PENDING && (
                <section className="space-y-6">
                   <div className="bg-indigo-600 rounded-[2rem] p-6 text-white shadow-xl shadow-indigo-100 flex flex-col items-center text-center">
                      <Zap className="mb-2 text-indigo-200" size={32} />
                      <h4 className="text-lg font-black tracking-tight mb-1">Instant Claim</h4>
                      <p className="text-[10px] text-indigo-100 font-medium mb-6">Take this task immediately at the requester's budget.</p>
                      <button onClick={handleInstantAccept} className="w-full py-4 bg-white text-indigo-600 rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 transition-all">
                        Accept for Ksh {selectedErrand.budget}
                      </button>
                   </div>

                   <div className="relative py-4">
                      <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
                      <div className="relative flex justify-center"><span className="bg-white px-4 text-[10px] font-black text-gray-300 uppercase tracking-widest">or make an offer</span></div>
                   </div>

                   <div className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100 space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-1">
                           <label className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Your Price (Ksh)</label>
                           <input type="number" value={bidPrice} onChange={e => setBidPrice(Number(e.target.value))} className="w-full p-3 bg-transparent border-b border-gray-200 font-black text-sm text-gray-900 outline-none focus:border-indigo-600 rounded-none transition-all" />
                         </div>
                         <div className="space-y-1">
                           <label className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Your ETA</label>
                           <input type="text" placeholder="e.g. 25 mins" value={bidEta} onChange={e => setBidEta(e.target.value)} className="w-full p-3 bg-transparent border-b border-gray-200 font-black text-sm text-gray-900 outline-none focus:border-indigo-600 rounded-none transition-all" />
                         </div>
                      </div>
                      <button onClick={handlePlaceBid} className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">
                        Submit Offer
                      </button>
                   </div>
                </section>
              )}

              {!isRunner && selectedErrand.status === ErrandStatus.PENDING && (
                <section className="space-y-4">
                   <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Active Offers ({selectedErrand.bids.length})</h4>
                   <div className="space-y-3">
                      {selectedErrand.bids.map((bid, i) => (
                        <div key={i} className="bg-white border border-gray-100 p-4 rounded-3xl flex items-center justify-between shadow-sm">
                           <div className="flex items-center gap-3">
                             <img src={`https://i.pravatar.cc/100?u=${bid.runnerId}`} className="w-10 h-10 rounded-xl shadow-sm" />
                             <div>
                               <p className="text-xs font-black text-gray-900">{bid.runnerName}</p>
                               <div className="flex items-center gap-1">
                                 <Star size={8} className="text-amber-500 fill-amber-500" />
                                 <span className="text-[9px] font-black text-gray-400">{bid.runnerRating.toFixed(1)} • {bid.eta || '15 min'}</span>
                               </div>
                             </div>
                           </div>
                           <div className="text-right">
                             <p className="text-xs font-black text-emerald-600 mb-1">Ksh {bid.price}</p>
                             <button onClick={() => handleAcceptBid(bid)} className="px-3 py-1.5 bg-indigo-600 text-white text-[8px] font-black uppercase tracking-widest rounded-lg">Select</button>
                           </div>
                        </div>
                      ))}
                   </div>
                   
                   <div className="pt-4">
                      <button 
                        onClick={() => setConfirmCancel(true)}
                        className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-red-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                      >
                        <Trash2 size={14} /> Cancel Errand
                      </button>
                   </div>
                </section>
              )}
              
              {isRunner && selectedErrand.status === ErrandStatus.ACCEPTED && (
                <section className="space-y-4">
                  <div className="flex gap-2">
                    <button onClick={() => firebaseService.updateRunnerStatus(selectedErrand.id, "Package Picked Up")} className="flex-1 py-4 bg-amber-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">Picked Up <Package size={14} /></button>
                    <button onClick={() => firebaseService.updateRunnerStatus(selectedErrand.id, "Heading to Dropoff")} className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">Navigating <Navigation size={14} /></button>
                  </div>
                  <button onClick={() => firebaseService.submitForReview(selectedErrand.id, "Task done.")} className="w-full py-5 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em]">Complete Delivery</button>
                </section>
              )}
              {!isRunner && selectedErrand.status === ErrandStatus.VERIFYING && (
                <section className="bg-emerald-50 p-6 rounded-[2.5rem] border border-emerald-100 space-y-6">
                   <div className="space-y-4">
                      <p className="text-[9px] font-black text-emerald-700 uppercase tracking-widest">Rate the Service</p>
                      <div className="flex gap-4 justify-center">
                        {[1,2,3,4,5].map(star => (
                          <button key={star} onClick={() => setVerifyRating(star)} className={`w-10 h-10 bg-white rounded-xl shadow-sm border flex items-center justify-center ${verifyRating >= star ? 'text-amber-500 border-amber-200' : 'text-gray-200 border-emerald-100'}`}>
                            <Star size={20} className={verifyRating >= star ? "fill-current" : ""} />
                          </button>
                        ))}
                      </div>
                      <SignaturePad onSave={(sig) => handleCompleteErrand(verifyRating, sig)} />
                   </div>
                </section>
              )}
              {selectedErrand.status === ErrandStatus.COMPLETED && (
                <section className="bg-gray-900 rounded-[2.5rem] p-8 text-white space-y-6">
                   <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 bg-emerald-500 rounded-3xl flex items-center justify-center mb-4"><Check size={32} /></div>
                      <h4 className="text-xl font-black tracking-tight">Operation Completed</h4>
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">Payment successfully released</p>
                   </div>
                </section>
              )}
           </div>
           {selectedErrand.status !== ErrandStatus.COMPLETED && selectedErrand.status !== ErrandStatus.CANCELLED && (
             <div className="absolute bottom-0 left-0 right-0 p-6 bg-white border-t border-gray-100 flex gap-3">
                <button onClick={() => setShowChat(true)} className="flex-1 py-4 bg-gray-50 text-gray-900 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">Secure Chat <MessageSquare size={14} /></button>
                <button className="p-4 bg-gray-50 text-red-500 rounded-2xl"><Flag size={18} /></button>
             </div>
           )}
           {showChat && <ChatView errand={selectedErrand} user={auth.user!} onClose={() => setShowChat(false)} onRefresh={refreshData} />}
        </div>
      )}
    </Layout>
  );
};

export default App;
